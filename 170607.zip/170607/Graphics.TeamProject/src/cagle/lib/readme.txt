Build Version.

Visual studio 2017 (v141)